// 配置服务器相关信息
export default {
    host: "http://localhost:3000",
    mobileHost: "http://448po88612.zicp.vip",
};
